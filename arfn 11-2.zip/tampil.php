<?php

include('function.php');

$user = query("SELECT * FROM tb_user");
?>

<!DOCTYPE html>
<html>
<head>

    <title>Data</title>
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">

</head>
<body>
    <div class="container" style="margin-top: 20px">
    <div class="row">
    <div class="col-md-12">
    <h2 style="text-align: center;margin-bottom: 30px">Database</h2>
    <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">



<table>
    <tr >
        <th scope="col"> No. </th>
        <th scope="col"> Nama. </th>
        <th scope="col"> User Name. </th>
        <th scope="col"> Password </th>

    </tr>
    <?php $no = 1; ?>
    <?php foreach ($user as $data) : ?>
    <tr>
        <td> <?php echo $no; ?> </td>
        <td> <?php echo $data["nama"];?> </td>
        <td> <?php echo $data["user_name"];?> </td>
        <td> <?php echo $data["password"];?> </td>
        <td><a href="ubahdata.php?id=<?=$data["id"]; ?> ">Ubah</a>
        <a href="hapus.php?id=<?=$data["id"]; ?> ">Hapus</a>
        <button  type="button" class="btn btn-primary"><i class="glyphicon glyphicon-pencil"></i></button>

    </tr>

    <?php $no++;?>
    <?php endforeach; ?>
    </table>
    <a href="tambahuser.php"><button type="button" class="bt btnsuccess btn-sm"><i class="fas fa-plus fa-sm"> Tambah Data</i></button></a>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">
        $(document).ready( function () {
            $('#table_id').DataTable();
        } );
    </script>
</script>
</body>
</html>